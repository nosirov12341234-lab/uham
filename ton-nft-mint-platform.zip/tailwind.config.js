/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Space Mono"', 'monospace'],
        body: ['"DM Sans"', 'sans-serif'],
      },
      colors: {
        cyber: {
          bg: '#080c14',
          card: '#0d1524',
          border: '#1a2740',
          glow: '#00e5ff',
          accent: '#7b2fff',
          gold: '#f5c542',
          danger: '#ff3860',
          muted: '#4a5a78',
          text: '#c8d8f0',
        },
      },
      backgroundImage: {
        'gradient-cyber': 'linear-gradient(135deg, #7b2fff 0%, #00e5ff 100%)',
        'gradient-gold': 'linear-gradient(135deg, #f5c542 0%, #e88c00 100%)',
        'gradient-dark': 'linear-gradient(180deg, #0d1524 0%, #080c14 100%)',
      },
      animation: {
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
        'scan': 'scan 3s linear infinite',
        'float': 'float 6s ease-in-out infinite',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 20px rgba(0,229,255,0.3)' },
          '50%': { boxShadow: '0 0 40px rgba(0,229,255,0.7), 0 0 80px rgba(123,47,255,0.3)' },
        },
        scan: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100vh)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-12px)' },
        },
      },
      boxShadow: {
        'cyber': '0 0 30px rgba(0,229,255,0.2), inset 0 1px 0 rgba(255,255,255,0.05)',
        'cyber-lg': '0 0 60px rgba(0,229,255,0.3), 0 0 120px rgba(123,47,255,0.15)',
        'gold': '0 0 30px rgba(245,197,66,0.3)',
      },
    },
  },
  plugins: [],
};
