/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"DM Sans"', 'sans-serif'],
        mono: ['"Space Mono"', 'monospace'],
      },
      colors: {
        g: {
          bg:      '#0a0a0f',
          surface: '#111118',
          card:    '#16161f',
          border:  '#1e1e2e',
          hover:   '#22223a',
          muted:   '#4a4a6a',
          text:    '#b0b0d0',
          white:   '#e8e8f8',
          blue:    '#4f8eff',
          cyan:    '#00d4ff',
          purple:  '#7c3aed',
          green:   '#10b981',
          red:     '#ef4444',
          gold:    '#f59e0b',
        },
      },
      borderRadius: {
        xl: '16px',
        '2xl': '20px',
        '3xl': '28px',
      },
      boxShadow: {
        card: '0 1px 3px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.04)',
        'card-hover': '0 4px 16px rgba(0,0,0,0.5), 0 0 0 1px rgba(79,142,255,0.2)',
        blue: '0 0 20px rgba(79,142,255,0.25)',
        glow: '0 0 40px rgba(79,142,255,0.15)',
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease forwards',
        'slide-up': 'slideUp 0.5s cubic-bezier(0.22,1,0.36,1) forwards',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: { from: { opacity: '0' }, to: { opacity: '1' } },
        slideUp: { from: { opacity: '0', transform: 'translateY(20px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
      },
    },
  },
  plugins: [],
};
